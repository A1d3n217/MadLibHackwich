//
//  Class.swift
//  MadLibHackwich
//
//  Created by Wood, Aiden - Student on 10/1/24.
//

import Foundation
import SwiftUI


@Observable class myClass {
    var noun: String = ""
    var verb: String = ""
    var adjective: String = ""
}
